import pandas as pd
import numpy as np
import pickle #bilbio pour exporter modele
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.feature_selection import VarianceThreshold
#https://www.kaggle.com/uciml/pima-indians-diabetes-database/data


dataset = pd.read_csv("diabetes.csv")

dataset.head();

#columns_target = ["Outcome"]
#columns_train= ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI", "DiabetesPedigreeFunction", "Age" ]

#X = dataset[columns_target]
#Y = dataset[columns_train]

#X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size = 0.3, random_state = 42)




print(dataset.describe())
X = dataset.iloc[:, 0:8]
y = dataset.iloc[:, 8]


zero_not_accepted = ['Glucose', 'BloodPressure', 'SkinThickness', 'BMI', 'Insulin']





for column in zero_not_accepted:
   X[column] = X[column].replace(0, np.NaN)
   mean = int(X[column].mean(skipna=True))
   X[column] = X[column].replace(np.NaN, mean)

#Split des donnees pour la construcction du modele et son test
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0, test_size=0.20)


y_test.isnull().sum()

classifier = SVC(random_state=0, kernel='rbf')
classifier.fit(X_train, y_train)
print("Score avec svm : ")
print(classifier.score(X_test,y_test))




#Avec : logistic Regression
print("Avec Logistic Regression : ")
from sklearn.linear_model import LogisticRegression
classifier=LogisticRegression(random_state=0)
classifier.fit(X_train,y_train)
print(classifier.score(X_test, y_test))


#Random Forest
print("Avec Random Forest : ")
from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier(n_estimators=15, max_depth=None, min_samples_split=2, random_state=0);
classifier.fit(X_train, y_train)
print(classifier.score(X_test, y_test))
print("Classement features par ordre d'importance")
print(pd.Series(classifier.feature_importances_,index=X.columns).sort_values(ascending=False))
print("Random Forest en gardant les meilleurs features")


test = [[1,189,60,23,846,30.1,0.39,57]]
print(classifier.predict(test))
